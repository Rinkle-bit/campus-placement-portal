# CampusConnect — Campus Placement Portal

A polished full-stack final-year college project that helps students browse jobs and apply, while placement-cell administrators publish and manage opportunities.

## Features

- Student registration and JWT login
- Secure password hashing with bcrypt
- Job listing and one-click applications
- Student application tracker
- Admin dashboard with placement statistics
- Admin job creation and deletion
- SQLite database that creates and seeds itself on first run

## Technology

- Frontend: React 19 + Vite 8
- Backend: Node.js + Express 5
- Database: SQLite (`better-sqlite3`)
- Authentication: JSON Web Tokens

## Run locally

1. Install Node.js 22.12 or newer (Node 22 LTS is recommended).
2. In this folder, run `npm install`.
3. Run `npm run dev`.
4. Open the Vite URL printed in the terminal (usually `http://localhost:5173`).

Demo credentials:

- Student: `student@college.edu` / `student123`
- Admin: `admin@college.edu` / `admin123`

## Suggested report sections

Use the project title **CampusConnect: A Web-Based Campus Placement Management System**. Your report can cover the problem statement, requirements, architecture, database schema (users, jobs, applications), UI screenshots, testing, and future scope (resume upload, email alerts, company accounts, interview scheduling).

## Production note

Copy `.env.example` to `.env` and set a strong, unique `JWT_SECRET` before deployment. Never commit `.env` or the SQLite database. This project pins modern compatible dependency ranges; run `npm install` from a clean folder to resolve them.

## Deploy online with Render

1. Create a GitHub repository and upload the contents of this folder (not the enclosing folder).
2. In Render, select **New > Web Service**, then connect that repository.
3. Select **Node** and enter these commands:
   - Build command: `npm install && npm run build`
   - Start command: `npm start`
4. Add environment variable `JWT_SECRET` with a long random value.
5. Deploy. Render provides a public `onrender.com` URL.

The application serves the frontend and API from one URL in production. The default SQLite database is temporary on free hosting: data resets after a restart/redeploy. To preserve student accounts and applications, use a paid persistent disk and add `DATABASE_PATH=/opt/render/project/src/data/placement.db`, with disk mount path `/opt/render/project/src/data`. For a serious production deployment, replace SQLite with Render Postgres.
