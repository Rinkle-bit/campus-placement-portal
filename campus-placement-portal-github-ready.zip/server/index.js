import 'dotenv/config.js';
import express from 'express';
import cors from 'cors';
import Database from 'better-sqlite3';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const app = express();
const databasePath = process.env.DATABASE_PATH || path.join(__dirname, 'placement.db');
fs.mkdirSync(path.dirname(databasePath), { recursive: true });
const db = new Database(databasePath);
const SECRET = process.env.JWT_SECRET || 'change-this-secret-before-production';

app.use(cors());
app.use(express.json());

db.exec(`
  CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, email TEXT UNIQUE NOT NULL,
    password TEXT NOT NULL, role TEXT NOT NULL DEFAULT 'student', course TEXT, created_at TEXT DEFAULT CURRENT_TIMESTAMP
  );
  CREATE TABLE IF NOT EXISTS jobs (
    id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT NOT NULL, company TEXT NOT NULL, location TEXT NOT NULL,
    package TEXT NOT NULL, description TEXT NOT NULL, deadline TEXT NOT NULL, created_at TEXT DEFAULT CURRENT_TIMESTAMP
  );
  CREATE TABLE IF NOT EXISTS applications (
    id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL, job_id INTEGER NOT NULL,
    status TEXT NOT NULL DEFAULT 'Applied', created_at TEXT DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(user_id, job_id), FOREIGN KEY(user_id) REFERENCES users(id), FOREIGN KEY(job_id) REFERENCES jobs(id)
  );
`);

function seed() {
  const exists = db.prepare('SELECT id FROM users WHERE email = ?').get('admin@college.edu');
  if (!exists) {
    db.prepare('INSERT INTO users (name,email,password,role,course) VALUES (?,?,?,?,?)')
      .run('Placement Admin', 'admin@college.edu', bcrypt.hashSync('admin123', 10), 'admin', 'Administration');
    db.prepare('INSERT INTO users (name,email,password,role,course) VALUES (?,?,?,?,?)')
      .run('Demo Student', 'student@college.edu', bcrypt.hashSync('student123', 10), 'student', 'B.Tech CSE');
  }
  if (!db.prepare('SELECT id FROM jobs LIMIT 1').get()) {
    const add = db.prepare('INSERT INTO jobs (title,company,location,package,description,deadline) VALUES (?,?,?,?,?,?)');
    add.run('Software Engineer', 'TechNova', 'Bengaluru', '₹8 LPA', 'Build web applications with a collaborative engineering team.', '2026-10-15');
    add.run('Data Analyst', 'Insight Labs', 'Hyderabad', '₹6.5 LPA', 'Analyse business data and create dashboards for clients.', '2026-10-22');
    add.run('Frontend Intern', 'PixelWorks', 'Remote', '₹25,000/month', 'Six-month internship for students experienced with React.', '2026-09-30');
  }
}
seed();

function auth(req, res, next) {
  const token = req.headers.authorization?.replace('Bearer ', '');
  try { req.user = jwt.verify(token, SECRET); next(); }
  catch { res.status(401).json({ message: 'Please sign in first.' }); }
}
function admin(req, res, next) {
  if (req.user.role !== 'admin') return res.status(403).json({ message: 'Admin access required.' });
  next();
}
function tokenFor(user) { return jwt.sign({ id: user.id, name: user.name, role: user.role }, SECRET, { expiresIn: '7d' }); }

app.post('/api/auth/register', (req, res) => {
  const { name, email, password, course } = req.body;
  if (!name || !email || !password || !course) return res.status(400).json({ message: 'Fill in every field.' });
  try {
    const result = db.prepare('INSERT INTO users (name,email,password,course) VALUES (?,?,?,?)')
      .run(name.trim(), email.toLowerCase().trim(), bcrypt.hashSync(password, 10), course.trim());
    const user = { id: result.lastInsertRowid, name, role: 'student' };
    res.status(201).json({ token: tokenFor(user), user });
  } catch { res.status(409).json({ message: 'An account with this email already exists.' }); }
});

app.post('/api/auth/login', (req, res) => {
  const user = db.prepare('SELECT * FROM users WHERE email = ?').get(req.body.email?.toLowerCase().trim());
  if (!user || !bcrypt.compareSync(req.body.password || '', user.password)) return res.status(401).json({ message: 'Invalid email or password.' });
  res.json({ token: tokenFor(user), user: { id: user.id, name: user.name, role: user.role, course: user.course } });
});

app.get('/api/jobs', (req, res) => res.json(db.prepare('SELECT * FROM jobs ORDER BY created_at DESC').all()));
app.post('/api/jobs', auth, admin, (req, res) => {
  const { title, company, location, package: salary, description, deadline } = req.body;
  if (![title, company, location, salary, description, deadline].every(Boolean)) return res.status(400).json({ message: 'Fill in every job field.' });
  const result = db.prepare('INSERT INTO jobs (title,company,location,package,description,deadline) VALUES (?,?,?,?,?,?)').run(title, company, location, salary, description, deadline);
  res.status(201).json(db.prepare('SELECT * FROM jobs WHERE id = ?').get(result.lastInsertRowid));
});
app.delete('/api/jobs/:id', auth, admin, (req, res) => {
  db.prepare('DELETE FROM applications WHERE job_id = ?').run(req.params.id);
  const result = db.prepare('DELETE FROM jobs WHERE id = ?').run(req.params.id);
  if (!result.changes) return res.status(404).json({ message: 'Job not found.' });
  res.status(204).end();
});
app.get('/api/applications/mine', auth, (req, res) => {
  res.json(db.prepare(`SELECT a.*, j.title, j.company, j.location, j.package FROM applications a JOIN jobs j ON j.id=a.job_id WHERE a.user_id=? ORDER BY a.created_at DESC`).all(req.user.id));
});
app.post('/api/jobs/:id/apply', auth, (req, res) => {
  if (req.user.role !== 'student') return res.status(403).json({ message: 'Only students can apply.' });
  if (!db.prepare('SELECT id FROM jobs WHERE id = ?').get(req.params.id)) return res.status(404).json({ message: 'Job not found.' });
  try { db.prepare('INSERT INTO applications (user_id,job_id) VALUES (?,?)').run(req.user.id, req.params.id); res.status(201).json({ message: 'Application submitted!' }); }
  catch { res.status(409).json({ message: 'You already applied for this job.' }); }
});
app.get('/api/admin/summary', auth, admin, (req, res) => {
  const count = table => db.prepare(`SELECT COUNT(*) count FROM ${table}`).get().count;
  res.json({ students: db.prepare("SELECT COUNT(*) count FROM users WHERE role='student'").get().count, jobs: count('jobs'), applications: count('applications'), recent: db.prepare(`SELECT a.*,u.name,j.title,j.company FROM applications a JOIN users u ON u.id=a.user_id JOIN jobs j ON j.id=a.job_id ORDER BY a.created_at DESC LIMIT 10`).all() });
});

app.use(express.static(path.join(__dirname, '..', 'dist')));
app.use((req, res) => res.sendFile(path.join(__dirname, '..', 'dist', 'index.html')));

const port = process.env.PORT || 5000;
app.listen(port, () => console.log(`CampusConnect running on port ${port}`));
